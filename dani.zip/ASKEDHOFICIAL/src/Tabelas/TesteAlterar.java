package Tabelas;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TesteAlterar {

    public static void main(String[] args) throws SQLException {
        Connection con = new ConnectionFactory().getConnection();
        String sql = "update funcionario set nome = ? where matricula = ?";
        String sql2 = "update funcionario set cargo = ? where matricula = ?";

        try {
            PreparedStatement stmt1 = con.prepareStatement(sql);
            PreparedStatement stmt2 = con.prepareStatement(sql2);
            stmt1.setString(1, "Amanda");
            stmt1.setString(2, "123");
            stmt2.setString(1, "Responsavel");
            stmt2.setString(2, "165");
            stmt1.execute();
            stmt2.execute();
            stmt1.close();
            stmt2.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        
       //System.out.println("FOI/2");
    }

}
