package Tabelas;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

public class ExcluirFunc {

    private Connection con;
    PreparedStatement stmt;

    ExcluirFunc() {
        con = new ConnectionFactory().getConnection();
    }
    
    public void deletarFuncionario( Funcionario f)  throws SQLException{
        
        String sql = " Delete from funcionario where matricula = ?";
        
        try{
            stmt = con.prepareStatement(sql);
            stmt.setString(1, f.getMatricula());
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        
    }
}
