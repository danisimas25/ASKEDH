package model.dao;

import Connection.ConnectionFactory;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import model.bean.Evento;

public class EventoDAO {

    protected Connection con;

    public EventoDAO() {
        this.con = new ConnectionFactory().getConnection();
    }

    public void inserirEvento(Evento e) {
        String sql = "call inserir_Even(?,?,?,?,?,?,?,?,?)";
        try {
            CallableStatement cs = con.prepareCall(sql);
            cs.setInt(1, e.getCodigo());
            cs.setString(2, e.getNome());
            cs.setString(3, e.getOrganizador());
            cs.setString(4, e.getDesEven());
            Calendar horaI = e.getHoraInicio().getInstance();
            Time hrIni = new Time(horaI.get(Calendar.HOUR_OF_DAY), horaI.get(Calendar.MINUTE), (Calendar.SECOND));
            cs.setTime(5, hrIni);
            Calendar horaF = e.getHoraFinal().getInstance();
            Time hrInF = new Time(horaF.get(Calendar.HOUR_OF_DAY), horaF.get(Calendar.MINUTE), (Calendar.SECOND));
            cs.setTime(6, hrInF);
            cs.setDate(7, (java.sql.Date) e.getDataInicioEven().getTime());
            cs.setDate(8, (java.sql.Date) e.getDataFimEven().getTime());
            cs.setString(9, e.getFuncionario().getMatricula());
            cs.executeUpdate();
            cs.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void atualizarEvento(Evento e) {
        String sql = "call atualiza_Even(?,?,?,?,?)";
        try {
            CallableStatement cs = con.prepareCall(sql);
            cs.setString(1, e.getNome());
            Calendar hI = e.getHoraInicio().getInstance();
            Time hrI = new Time(hI.get(Calendar.HOUR_OF_DAY), hI.get(Calendar.MINUTE), hI.get(Calendar.SECOND));
            cs.setTime(2, hrI);
            Calendar hF = e.getHoraInicio().getInstance();
            Time hrF = new Time(hF.get(Calendar.HOUR_OF_DAY), hF.get(Calendar.MINUTE), hF.get(Calendar.SECOND));
            cs.setTime(3, hrF);
            cs.setDate(4, (java.sql.Date) e.getDataFimEven().getTime());
            cs.setInt(5, e.getCodigo());
            cs.executeUpdate();
            cs.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void deletarEvento(Evento e) {
        String sql = "call deleta_Even(?)";
        try {
            CallableStatement cs = con.prepareCall(sql);
            cs.setInt(1, e.getCodigo());
            cs.executeUpdate();
            cs.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }

    }

    public List<Evento> getLista() {
        List<Evento> even = new ArrayList();
        String sql = "call Lista_Even()";
        PreparedStatement ps = null;
        ResultSet rs = null;
        FuncionarioDAO funcDao = new FuncionarioDAO();
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Evento e = new Evento();
                e.setCodigo(rs.getInt("codigo"));
                e.setNome(rs.getString("nome"));
                e.setOrganizador(rs.getString("organizador"));
                e.setDesEven(rs.getString("descricao"));
                Calendar hI = Calendar.getInstance();
                hI.setTime(rs.getTime("horaInicial"));
                e.setHoraInicio(hI);
                Calendar hF = Calendar.getInstance();
                hI.setTime(rs.getTime("horaFinal"));
                e.setHoraFinal(hF);
                Calendar dI = Calendar.getInstance();
                dI.setTime(rs.getDate("dataInicio"));
                e.setDataInicioEven(dI);
                Calendar dF = Calendar.getInstance();
                dF.setTime(rs.getDate("horaInicial"));
                e.setDataFimEven(dF);
                e.setFuncionario(funcDao.getListaFunc("funcRegistra"));
                even.add(e);
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return even;
    }

    public Evento getEvento(int evento) {
        String sql = "pesquisar_Even()";
        Evento e = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        FuncionarioDAO funcDao = new FuncionarioDAO();
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, evento);
            rs = ps.executeQuery();
            while (rs.next()) {
                e = new Evento();
                e.setCodigo(rs.getInt("codigo"));
                e.setNome(rs.getString("nome"));
                e.setOrganizador(rs.getString("organizador"));
                e.setDesEven(rs.getString("descricao"));
                Calendar hI = Calendar.getInstance();
                hI.setTime(rs.getTime("horaInicial"));
                e.setHoraInicio(hI);
                Calendar hF = Calendar.getInstance();
                hI.setTime(rs.getTime("horaFinal"));
                e.setHoraFinal(hF);
                Calendar dI = Calendar.getInstance();
                dI.setTime(rs.getDate("dataInicio"));
                e.setDataInicioEven(dI);
                Calendar dF = Calendar.getInstance();
                dF.setTime(rs.getDate("horaInicial"));
                e.setDataFimEven(dF);
                e.setFuncionario(funcDao.getListaFunc("funcRegistra"));
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return e;
    }

}
