package model.dao;

import java.sql.Connection;
import java.sql.SQLException;
import Connection.ConnectionFactory;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.bean.Funcionario;

public class FuncionarioDAO {

    protected Connection con;

    public FuncionarioDAO() {
        this.con = new ConnectionFactory().getConnection();
    }
    
    public void adicionarFuncionario(Funcionario f) {
        String sql = "insert into Funcionario values (?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getMatricula());
            ps.setString(2, f.getNome());
            ps.setString(3, f.getSenha());
            ps.setInt(4,f.getDepTo().getCodigo());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void atulizarFuncionario(Funcionario f) {
        String sql = "update Funcionario set nome = ?, depCod = ?, where matricula = ? ";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getNome());
            ps.setInt(2,f.getDepTo().getCodigo());
            ps.setString(3, f.getMatricula());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void deletarFuncionario(Funcionario f) {
        String sql = "delete from Funcionario where matricula = ?";
        try {
            con = new ConnectionFactory().getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getMatricula());
            ps.execute();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public List<Funcionario> getLista() {
        List<Funcionario> f = new ArrayList();
        String sql = "select * from funcionario";
        PreparedStatement ps = null;
        ResultSet rs = null;
        DepartamentoDAO deptoDao=new DepartamentoDAO();
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Funcionario func = new Funcionario();
                func.setMatricula(rs.getString("matricula"));
                func.setNome(rs.getString("nome"));
                func.setSenha(rs.getString("senha"));
                func.setDepTo(deptoDao.getDepartamento(rs.getInt("codDep")));
                f.add(func);
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return f;
    }

    public Funcionario getListaFunc(String fu) {
        String sql = "select * from funcionario where matricula = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        Funcionario func = null;
        DepartamentoDAO deptoDao=new DepartamentoDAO();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1,"fu");
            rs = ps.executeQuery();
            while (rs.next()) {
                func = new Funcionario();
                func.setMatricula(rs.getString("matricula"));
                func.setNome(rs.getString("nome"));
                func.setSenha(rs.getString("senha"));
                func.setDepTo(deptoDao.getDepartamento(rs.getInt("codDep")));
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return func;
    }
}
