package view;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import model.bean.Evento;
import model.bean.Funcionario;
import model.dao.EventoDAO;
import model.dao.FuncionarioDAO;
import view.TelaInicio;

public class TelaCadEvento extends javax.swing.JFrame {

    public TelaCadEvento() {
        initComponents();
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/images/planeta.png")).getImage());
        FuncionarioDAO ddao = new FuncionarioDAO();

        for (Funcionario d : ddao.getLista()) {
            jbFunc.addItem(d);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField4 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        labelnomeEvento = new javax.swing.JLabel();
        labelcodCadEspaco = new javax.swing.JLabel();
        labelNomeOganizador = new javax.swing.JLabel();
        btnMenuEvento = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        btnCanEvento = new javax.swing.JButton();
        txtCodigo = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtDescricao = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtDataI = new javax.swing.JTextField();
        txtHoraInicial = new javax.swing.JTextField();
        txtDataF = new javax.swing.JTextField();
        txtHoraFinal = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jbFunc = new javax.swing.JComboBox<>();
        Func = new javax.swing.JLabel();
        txtOrganizador = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jPesq = new javax.swing.JMenuItem();
        jEditar = new javax.swing.JMenuItem();
        jmiExcluir = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        jTextField4.setText("jTextField4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro de eventos");
        setSize(new java.awt.Dimension(1200, 678));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        labelnomeEvento.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelnomeEvento.setForeground(new java.awt.Color(255, 255, 255));
        labelnomeEvento.setText("Nome do evento");

        labelcodCadEspaco.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelcodCadEspaco.setForeground(new java.awt.Color(255, 255, 255));
        labelcodCadEspaco.setText("Código");

        labelNomeOganizador.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelNomeOganizador.setForeground(new java.awt.Color(255, 255, 255));
        labelNomeOganizador.setText("Organizador (a)");

        btnMenuEvento.setBackground(new java.awt.Color(153, 153, 255));
        btnMenuEvento.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        btnMenuEvento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/voltar.png"))); // NOI18N
        btnMenuEvento.setText("Voltar");
        btnMenuEvento.setBorder(null);
        btnMenuEvento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMenuEventoActionPerformed(evt);
            }
        });

        btnAdd.setBackground(new java.awt.Color(153, 153, 255));
        btnAdd.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/entrar.png"))); // NOI18N
        btnAdd.setText("Adicionar");
        btnAdd.setBorder(null);
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnCanEvento.setBackground(new java.awt.Color(153, 153, 255));
        btnCanEvento.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        btnCanEvento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/limpar.png"))); // NOI18N
        btnCanEvento.setText("Limpar");
        btnCanEvento.setBorder(null);
        btnCanEvento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCanEventoActionPerformed(evt);
            }
        });

        txtCodigo.setBackground(new java.awt.Color(0, 0, 0));
        txtCodigo.setForeground(new java.awt.Color(255, 255, 255));
        txtCodigo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        txtNome.setBackground(new java.awt.Color(0, 0, 0));
        txtNome.setForeground(new java.awt.Color(255, 255, 255));
        txtNome.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        txtDescricao.setBackground(new java.awt.Color(0, 0, 0));
        txtDescricao.setForeground(new java.awt.Color(255, 255, 255));
        txtDescricao.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/glx.PNG"))); // NOI18N
        jLabel2.setText("jLabel2");

        jLabel4.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Descrição");
        jLabel4.setToolTipText("");

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Horários");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/glx2.PNG"))); // NOI18N
        jLabel3.setText("jLabel3");

        txtDataI.setBackground(new java.awt.Color(0, 0, 0));
        txtDataI.setForeground(new java.awt.Color(255, 255, 255));
        txtDataI.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        txtHoraInicial.setBackground(new java.awt.Color(0, 0, 0));
        txtHoraInicial.setForeground(new java.awt.Color(255, 255, 255));
        txtHoraInicial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));
        txtHoraInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoraInicialActionPerformed(evt);
            }
        });

        txtDataF.setBackground(new java.awt.Color(0, 0, 0));
        txtDataF.setForeground(new java.awt.Color(255, 255, 255));
        txtDataF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        txtHoraFinal.setBackground(new java.awt.Color(0, 0, 0));
        txtHoraFinal.setForeground(new java.awt.Color(255, 255, 255));
        txtHoraFinal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));
        txtHoraFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoraFinalActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Datas");
        jLabel7.setToolTipText("");

        jbFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbFuncActionPerformed(evt);
            }
        });

        Func.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        Func.setForeground(new java.awt.Color(255, 255, 255));
        Func.setText("Funcionário");

        txtOrganizador.setBackground(new java.awt.Color(0, 0, 0));
        txtOrganizador.setForeground(new java.awt.Color(255, 255, 255));
        txtOrganizador.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Func)
                    .addComponent(jLabel4)
                    .addComponent(labelNomeOganizador)
                    .addComponent(labelnomeEvento)
                    .addComponent(labelcodCadEspaco))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNome, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
                            .addComponent(txtCodigo)
                            .addComponent(txtOrganizador))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDataI, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(txtHoraInicial))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtHoraFinal, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(txtDataF)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jbFunc, javax.swing.GroupLayout.Alignment.LEADING, 0, 240, Short.MAX_VALUE)
                        .addComponent(txtDescricao, javax.swing.GroupLayout.Alignment.LEADING)))
                .addContainerGap(198, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 531, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81)
                .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addComponent(btnCanEvento, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(btnMenuEvento, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelcodCadEspaco)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDataI, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDataF, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelnomeEvento, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtHoraInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHoraFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNomeOganizador, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtOrganizador, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Func)
                    .addComponent(jbFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCanEvento, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMenuEvento, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel2)))
        );

        jMenu1.setBorder(null);
        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pasta.png"))); // NOI18N
        jMenu1.setText("Outras funções");
        jMenu1.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N

        jPesq.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        jPesq.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pesquisarr.png"))); // NOI18N
        jPesq.setText("Pesquisar");
        jPesq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPesqActionPerformed(evt);
            }
        });
        jMenu1.add(jPesq);

        jEditar.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        jEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/editar.png"))); // NOI18N
        jEditar.setText("Editar");
        jEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEditarActionPerformed(evt);
            }
        });
        jMenu1.add(jEditar);

        jmiExcluir.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        jmiExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/excluir.png"))); // NOI18N
        jmiExcluir.setText("Excluir");
        jmiExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiExcluirActionPerformed(evt);
            }
        });
        jMenu1.add(jmiExcluir);

        jMenuBar1.add(jMenu1);
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jmiExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiExcluirActionPerformed
       new TelaExcluirEvento().setVisible(true);
       dispose();
    }//GEN-LAST:event_jmiExcluirActionPerformed

    private void jPesqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPesqActionPerformed
        
        new TelaPesqEven().setVisible(true);
        dispose();
    }//GEN-LAST:event_jPesqActionPerformed

    private void txtHoraFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraFinalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraFinalActionPerformed

    private void txtHoraInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraInicialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraInicialActionPerformed

    private void btnCanEventoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCanEventoActionPerformed
        limparTela();
    }//GEN-LAST:event_btnCanEventoActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
       
        
        Evento d = new Evento();
        EventoDAO ed = new EventoDAO();
        d.setCodigo(Integer.parseInt(txtCodigo.getText()));
        d.setNome(txtNome.getText());
        d.setOrganizador(txtOrganizador.getText());
        d.setDesEven(txtDescricao.getText());
        d.setHoraInicio(txtHoraInicial.getText());
        d.setHoraFinal(txtHoraFinal.getText());

        /*DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        try {

            formatter.parse(txtDataI.getText());

            Calendar cal = Calendar.getInstance();
            cal.setTime(dt);
            int dia = cal.get(Calendar.DAY_OF_MONTH);
            int mes = cal.get(Calendar.MONTH);
            int ano = cal.get(Calendar.YEAR);
        } catch (ParseException e) {
            // This can happen if you are trying to parse an invalid date, e.g., 25:19:12.
            // Here, you should log the error and decide what to do next
            e.printStackTrace();
        }*/

        d.setDataInicioEven(txtDataI.getText());
        d.setDataFimEven(txtDataF.getText());
        d.setFuncionario((Funcionario) jbFunc.getSelectedItem());
        ed.inserirEvento(d);
        JOptionPane.showMessageDialog(this, "Cadastrado com sucesso!");
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnMenuEventoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMenuEventoActionPerformed
        TelaMultiDiren tmd = new TelaMultiDiren();
        tmd.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnMenuEventoActionPerformed

    private void jbFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbFuncActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbFuncActionPerformed

    private void jEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEditarActionPerformed
       new TelaEditarEven().setVisible(true);
       dispose();
    }//GEN-LAST:event_jEditarActionPerformed

    private void limparTela() {
        txtCodigo.setText("");
        txtNome.setText("");
        txtDescricao.setText("");
        txtOrganizador.setText("");
        txtHoraFinal.setText("");
        txtHoraInicial.setText("");
        txtDataI.setText("");
        txtDataF.setText("");

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadEvento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadEvento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadEvento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadEvento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadEvento().setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Func;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCanEvento;
    private javax.swing.JButton btnMenuEvento;
    private javax.swing.JMenuItem jEditar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem jPesq;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JComboBox<Object> jbFunc;
    private javax.swing.JMenuItem jmiExcluir;
    private javax.swing.JLabel labelNomeOganizador;
    private javax.swing.JLabel labelcodCadEspaco;
    private javax.swing.JLabel labelnomeEvento;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtDataF;
    private javax.swing.JTextField txtDataI;
    private javax.swing.JTextField txtDescricao;
    private javax.swing.JTextField txtHoraFinal;
    private javax.swing.JTextField txtHoraInicial;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtOrganizador;
    // End of variables declaration//GEN-END:variables

}
