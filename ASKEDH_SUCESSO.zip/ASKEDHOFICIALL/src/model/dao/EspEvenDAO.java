package model.dao;

import java.sql.Connection;
import Connection.ConnectionFactory;
//import com.itextpdf.text.Document;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.bean.EspEven;

public class EspEvenDAO {

    protected Connection con;

    public EspEvenDAO() {
        this.con = new ConnectionFactory().getConnection();
    }

    public void adicionarEspacoEvento(EspEven ve) {
        String sql = "insert into espeven values (?,?,?,?,?,?,?)" ;
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, ve.getEsp().getSigla());
            ps.setInt(2, ve.getEven().getCodigo());
            ps.setString(3, ve.getDtIni());
            ps.setString(4, ve.getDtF());
            ps.setString(5, ve.gethI());
            ps.setString(6, ve.gethF());
            ps.setString(7, ve.getSituacao());
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(null,"Inserido com sucesso !");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir !");
        }
    }

    public List<EspEven> getLista() {
        List<EspEven> espEven;
        espEven = new ArrayList<>();
        String sql = "select * from espEven";
        PreparedStatement ps = null;
        ResultSet rs = null;
        EventoDAO even = new EventoDAO();
        EspacoDAO esp = new EspacoDAO();
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                EspEven e = new EspEven();
                e.setEsp(esp.getEspacoE(rs.getString("siglaE")));
                e.setEven(even.getEvento(rs.getInt("evenCod")));
                e.setDtIni(rs.getString("dataInicio"));
                e.setDtF(rs.getString("dataFinal"));
                e.sethI(rs.getString("horaInicio"));
                e.sethF(rs.getString("horaFinal"));
                e.setSituacao(rs.getString("situacao"));
                espEven.add(e);
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return espEven;
    }

    public void atualizaEspEvenReservado(EspEven e) {
        String sql = "update espeven set  situcao = 'Reservado' where siglaE = ? and  evenCod = ? ";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(2, e.getSituacao());
            ps.setString(2, e.getEsp().getSigla());
            ps.setInt(3, e.getEven().getCodigo());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException p) {
            throw new RuntimeException(p);
        }

    }

    public void atualizaEspEvenDisponivel(EspEven e) {
        String sql = "update espeven set situcao = 'Disponivel', dataInicio = 0, dataFinal = null, horaInicio = null, horaFinal= null  where siglaE = ? and  evenCod = ? ";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, e.getSituacao());
            ps.setString(2,e.getDtIni());
            ps.setString(3,e.getDtF());
            ps.setString(4,e.gethI());
            ps.setString(5,e.gethF());
            ps.setString(6, e.getEsp().getSigla());
            ps.setInt(7, e.getEven().getCodigo());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException p) {
            throw new RuntimeException(p);
        }

    }

    public void deletarEspacoEvento(EspEven e) {

        String sql = "delete from EspEven where siglaE = ?,evenCod =? ";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, e.getEsp().getSigla());
            ps.setInt(2, e.getEven().getCodigo());
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + o);
        }
    }

}
