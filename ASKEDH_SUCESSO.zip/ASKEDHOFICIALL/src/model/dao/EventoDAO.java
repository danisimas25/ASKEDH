package model.dao;

import Connection.ConnectionFactory;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.bean.Evento;
import view.TelaCadEvento;

public class EventoDAO {

    TelaCadEvento t;
    protected Connection con;

    public EventoDAO() {
        this.con = new ConnectionFactory().getConnection();
    }

    public void inserirEvento(Evento e) {
        String sql = "call inserir_Even(?,?,?,?,?,?,?,?,?)";
        try {
            CallableStatement cs = con.prepareCall(sql);
            cs.setInt(1, e.getCodigo());
            cs.setString(2, e.getNome());
            cs.setString(3, e.getOrganizador());
            cs.setString(4, e.getDesEven());
            cs.setString(5, e.getHoraInicio());
            cs.setString(6, e.getHoraFinal());
            cs.setString(7, e.getDataInicioEven());
            cs.setString(8, e.getDataFimEven());
            cs.setString(9, e.getFuncionario().getMatricula());
            cs.executeUpdate();
            cs.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void atualizarEvento(Evento e) {
        String sql = "call atualiza_Even(?,?,?,?,?,?,?,?)";
        try {
            CallableStatement cs = con.prepareCall(sql);
            cs.setString(1, e.getNome());
            cs.setString(2,e.getOrganizador());
            cs.setString(3,e.getDesEven());
            cs.setString(4,e.getHoraInicio());
            cs.setString(5,e.getHoraFinal());
            cs.setString(6,e.getDataInicioEven());
            cs.setString(7,e.getDataFimEven());  
            cs.setInt(8, e.getCodigo());
            cs.executeUpdate();
            cs.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void deletarEvento(Evento e) {
        String sql = "delete from Evento where codigo = ?";
        try {
            CallableStatement cs = con.prepareCall(sql);
            cs.setInt(1, e.getCodigo());
            cs.executeUpdate();
            cs.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }

    }

    public List<Evento> getLeituraPeloCodigo(int cod) {
        List<Evento> even = new ArrayList();
        String sql = "call pesquisar_Even(?)";
        PreparedStatement ps = null;
        ResultSet rs = null;
        FuncionarioDAO funcDao = new FuncionarioDAO();
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, cod);
            rs = ps.executeQuery();
            while (rs.next()) {
                Evento e = new Evento();
                e.setCodigo(rs.getInt("codigo"));
                e.setNome(rs.getString("nome"));
                e.setOrganizador(rs.getString("organizador"));
                e.setDesEven(rs.getString("descricao"));
                e.setHoraInicio(rs.getString("horaInicial"));
                e.setHoraFinal(rs.getString("horaFinal"));
                e.setDataInicioEven(rs.getString("dataInicio"));
                e.setDataFimEven(rs.getString("dataFim"));
                e.setFuncionario(funcDao.getListaFuncionario(rs.getString("funcRegistra")));

                even.add(e);
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return even;
    }

    public List<Evento> getLista() {
        List<Evento> even = new ArrayList();
        String sql = "call Lista_Even()";
        PreparedStatement ps = null;
        ResultSet rs = null;
        FuncionarioDAO funcDao = new FuncionarioDAO();
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Evento e = new Evento();
                e.setCodigo(rs.getInt("codigo"));
                e.setNome(rs.getString("nome"));
                e.setOrganizador(rs.getString("organizador"));
                e.setDesEven(rs.getString("descricao"));
                e.setHoraInicio(rs.getString("horaInicial"));
                e.setHoraFinal(rs.getString("horaFinal"));
                e.setDataInicioEven(rs.getString("dataInicio"));
                e.setDataFimEven(rs.getString("dataFim"));
                e.setFuncionario(funcDao.getListaFuncionario(rs.getString("funcRegistra")));

                even.add(e);
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return even;
    }

    public Evento getEvento(int evento) {
        String sql = " call pesquisar_Even(?)";
        Evento e = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        FuncionarioDAO funcDao = new FuncionarioDAO();
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, evento);
            rs = ps.executeQuery();
            while (rs.next()) {
                e = new Evento();
                e.setCodigo(rs.getInt("codigo"));
                e.setNome(rs.getString("nome"));
                e.setOrganizador(rs.getString("organizador"));
                e.setDesEven(rs.getString("descricao"));
                e.setHoraInicio(rs.getString("horaInicial"));
                e.setHoraFinal(rs.getString("horaFinal"));
                e.setDataInicioEven(rs.getString("dataInicio"));
                e.setDataFimEven(rs.getString("dataFim"));
                e.setFuncionario(funcDao.getListaFuncionario(rs.getString("funcRegistra")));

            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return e;
    }

}
