package model.bean;

public class Departamento {

    protected int codigo;
    protected String nome;
    protected String sigla;

    public void setCodigo(int cod) {
        this.codigo = cod;
    }

    public void setNome(String n) {
        this.nome = n;
    }

    public void setSigla(String s) {
        this.sigla = s;
    }

    public int getCodigo() {
        return this.codigo;
    }

    public String getNome() {
        return this.nome;
    }

    public String getSigla() {
        return this.sigla;
    }

    @Override
    public String toString() {
        return getNome();
    }
    
    
}
