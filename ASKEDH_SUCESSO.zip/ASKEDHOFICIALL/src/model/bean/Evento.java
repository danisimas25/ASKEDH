package model.bean;

import model.bean.Funcionario;

public class Evento {

    protected int codigo;
    protected String nome;
    protected String organizador;
    protected Funcionario funcionario;
    protected Espaco espaco;
    protected String desEven;
    protected String dataInicioEven;
    protected String dataFimEven;
    protected String horaInicio;
    protected String horaFinal;
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getOrganizador() {
        return organizador;
    }

    public void setOrganizador(String organizador) {
        this.organizador = organizador;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Espaco getEspaco() {
        return espaco;
    }

    public void setEspaco(Espaco espaco) {
        this.espaco = espaco;
    }

    public String getDesEven() {
        return desEven;
    }

    public void setDesEven(String desEven) {
        this.desEven = desEven;
    }

    public String getDataInicioEven() {
        return dataInicioEven;
    }

    public void setDataInicioEven(String dataInicioEven) {
        this.dataInicioEven = dataInicioEven;
    }

    public String getDataFimEven() {
        return dataFimEven;
    }

    public void setDataFimEven(String dataFimEven) {
        this.dataFimEven = dataFimEven;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(String horaFinal) {
        this.horaFinal = horaFinal;
    }

//    @Override
//    public String toString() {
//        return 
//    }
    

      @Override
    public String toString() {
        return getNome();
    }
    
}
