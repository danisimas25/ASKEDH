package model.bean;

import model.bean.Departamento;

public class Espaco {

    protected String sigla;
    protected String tipo;
    protected String descricao;
    protected int capacidade;
    protected int qtdeCA;
    protected Departamento departamento;

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getQtdeCA() {
        return qtdeCA;
    }

    public void setQtdeCA(int qtdeCA) {
        this.qtdeCA = qtdeCA;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return getSigla();
    }

    
}
