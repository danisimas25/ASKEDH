/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Aluno
 */
public class EspEven {

    protected Espaco esp;
    protected Evento even;
    protected String dtIni;
    protected String dtF;
    protected String hI;
    protected String hF;
    protected String situacao;
    

    public String gethI() {
        return hI;
    }

    public void sethI(String hI) {
        this.hI = hI;
    }

    public String gethF() {
        return hF;
    }

    public void sethF(String hF) {
        this.hF = hF;
    }

    public Espaco getEsp() {
        return esp;
    }

    public void setEsp(Espaco esp) {
        this.esp = esp;
    }

    public Evento getEven() {
        return even;
    }

    public void setEven(Evento even) {
        this.even = even;
    }

    public String getDtIni() {
        return dtIni;
    }

    public void setDtIni(String dtIni) {
        this.dtIni = dtIni;
    }

    public String getDtF() {
        return dtF;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public void setDtF(String dtF) {
        this.dtF = dtF;
    }

}
