/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabelas;

import java.util.Calendar;
import model.bean.Evento;
import model.dao.EventoDAO;

/**
 *
 * @author Aluno
 */
public class TEstaaEvento {
    public static void main(String[] args) {
        EventoDAO dao=new EventoDAO();
        Evento evento = new Evento();
        evento.setCodigo(9);
        Calendar dtFim=Calendar.getInstance();
        dtFim.set(Calendar.DAY_OF_MONTH,17);
        dtFim.set(Calendar.MONTH,2);
        dtFim.set(Calendar.YEAR,2016);
        dtFim.set(Calendar.HOUR,8);
        dtFim.set(Calendar.MINUTE,30);
        dtFim.set(Calendar.SECOND,00);
        System.out.println(dtFim.get(Calendar.HOUR)+" "+dtFim.get(Calendar.MINUTE)+" "+dtFim.get(Calendar.SECOND));
        evento.setDataFimEven(dtFim);
        Calendar dtIni=Calendar.getInstance();
        evento.setDataInicioEven(dtIni);
        evento.setDesEven("asdfasdf");
        model.bean.Funcionario f=new model.bean.Funcionario();
        f.setMatricula("1234");
        evento.setFuncionario(f);
        evento.setNome("testeet");
        evento.setOrganizador("sei la");
        dao.inserirEvento(evento);
        
    }
    
}
