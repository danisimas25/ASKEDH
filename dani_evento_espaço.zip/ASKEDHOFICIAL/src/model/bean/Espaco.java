package model.bean;

public class Espaco {

    protected String sigla;
    protected char tipo;
    protected String descricao;
    protected int capacidade;
    protected int qtdeCA;
    protected Departamento depto;

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public char getTipo() {
        return tipo;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getQtdeCA() {
        return qtdeCA;
    }

    public void setQtdeCA(int qtdeCA) {
        this.qtdeCA = qtdeCA;
    }

    public Departamento getDepto() {
        return depto;
    }

    public void setDepto(Departamento depto) {
        this.depto = depto;
    }

}
