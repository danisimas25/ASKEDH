package model.dao;

import Connection.ConnectionFactory;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import model.bean.Evento;

public class EventoDAO {

    protected Connection con;

    public EventoDAO() {
        this.con = new ConnectionFactory().getConnection();
    }

    public void inserirEvento(Evento e) {
        String sql = "call inserir_Even(?,?,?,?,?,?,?,?,?)";
        try {
            CallableStatement cs = con.prepareCall(sql);
            cs.setInt(1, e.getCodigo());
            cs.setString(2, e.getNome());
            cs.setString(3, e.getOrganizador());
            cs.setString(4, e.getDesEven());
            Calendar horaI = e.getHoraInicio().getInstance();
            Time hrIni = new Time(horaI.get(Calendar.HOUR_OF_DAY), horaI.get(Calendar.MINUTE), horaI.get(Calendar.SECOND));
            cs.setTime(5, hrIni);
            Calendar horaF = e.getHoraFinal().getInstance();
            Time hrInF = new Time(horaF.get(Calendar.HOUR_OF_DAY), horaF.get(Calendar.MINUTE), horaF.get(Calendar.SECOND));
            cs.setTime(6, hrInF);
            cs.setDate(7, (java.sql.Date) e.getDataInicioEven().getTime());
            cs.set
            
            
            
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

}
