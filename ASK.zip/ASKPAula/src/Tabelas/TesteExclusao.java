
package Tabelas;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TesteExclusao {
    
    public static void main(String[] args)throws SQLException{
    
       PreparedStatement stmt;
       Connection con = new ConnectionFactory().getConnection();
       String sql = " Delete from funcionario where matricula = ?";
       
       try{
            stmt = con.prepareStatement(sql);
            stmt.setString(1,"090909");
       
            stmt.executeUpdate(); 
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
   }
}
