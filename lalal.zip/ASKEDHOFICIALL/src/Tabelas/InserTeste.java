package Tabelas;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

public class InserTeste {

    public static void main(String[] args) throws SQLException {
        Connection con = new ConnectionFactory().getConnection();
        String sql = "insert into funcionario" + "(matricula,nome,cargo,senha)"
                + "values(?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(2, "Amanda Teixeira");
        ps.setString(1, "123");
        ps.setString(3, "Responsavél");
        ps.setString(4, "abc");
        ps.executeUpdate();
        ps.setString(2, "Vee Simpson");
        ps.setString(1, "165");
        ps.setString(3, "Cooorde");
        ps.setString(4, "sql");
        ps.executeUpdate();
        ps.setString(2, "Doralice");
        ps.setString(1, "090909");
        ps.setString(3, "Responsavel");
        ps.setString(4,"dbc");
        ps.executeUpdate();
        ps.close();
        //System.out.println("FOI");
    }

}
