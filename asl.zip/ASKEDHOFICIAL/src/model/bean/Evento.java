package model.bean;

import java.util.Calendar;

public class Evento {

    protected int codigo;
    protected String nome;
    protected String organizador;
    protected Funcionario funcionario;
    protected Calendar dtRegistro;
    protected Espaco espaco;
    protected String desEven;
    protected Calendar dataInicioEven;
    protected Calendar dataFimEven;
    protected Calendar horaInicio;
    protected Calendar horaFinal;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getOrganizador() {
        return organizador;
    }

    public void setOrganizador(String organizador) {
        this.organizador = organizador;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Calendar getDtRegistro() {
        return dtRegistro;
    }

    public void setDtRegistro(Calendar dtRegistro) {
        this.dtRegistro = dtRegistro;
    }

    public Espaco getEspaco() {
        return espaco;
    }

    public void setEspaco(Espaco espaco) {
        this.espaco = espaco;
    }

    public String getDesEven() {
        return desEven;
    }

    public void setDesEven(String desEven) {
        this.desEven = desEven;
    }

    public Calendar getDataInicioEven() {
        return dataInicioEven;
    }

    public void setDataInicioEven(Calendar dataInicioEven) {
        this.dataInicioEven = dataInicioEven;
    }

    public Calendar getDataFimEven() {
        return dataFimEven;
    }

    public void setDataFimEven(Calendar dataFimEven) {
        this.dataFimEven = dataFimEven;
    }

    public Calendar getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Calendar horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Calendar getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(Calendar horaFinal) {
        this.horaFinal = horaFinal;
    }
    
    
}
