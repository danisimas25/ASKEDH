package model.bean;

public class Funcionario {

    protected String nome;
    protected String matricula;
    protected String senha;
    protected Departamento depTo;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Departamento getDepTo() {
        return depTo;
    }

    public void setDepTo(Departamento depTo) {
        this.depTo = depTo;
    }
   

}
