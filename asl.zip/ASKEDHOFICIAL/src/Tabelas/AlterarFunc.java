
package Tabelas;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AlterarFunc {
    
    Connection con;
    
    public AlterarFunc(){
        con = new ConnectionFactory().getConnection();
    }
    
    public void alteraFunc(Funcionario f){
        
        String sql = "update funcinario set nome = ? where matricula = ?";
        String sql2 = "update funcionario set cargo = ? where matricula = ?";
        
        try {
            
            PreparedStatement stmt1 = con.prepareStatement(sql);
            PreparedStatement stmt2 = con.prepareStatement(sql2);
            stmt1.setString(2,f.getNome());
            stmt1.setString(1,f.getMatricula());
            stmt2.setString(3,f.getCargo());
            stmt2.setString(1,f.getMatricula());
            stmt1.execute();
            stmt1.close();
            stmt2.execute();
            stmt2.close();
            
        } catch (SQLException e) {
           throw new RuntimeException(e);
        }
        
    }
}
