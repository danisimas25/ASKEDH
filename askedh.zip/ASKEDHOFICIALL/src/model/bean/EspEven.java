/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

import java.util.Calendar;
import model.bean.Espaco;
import model.bean.Espaco;
import model.bean.Evento;
import model.bean.Evento;

/**
 *
 * @author Aluno
 */
public class EspEven {

    protected Espaco esp;
    protected Evento even;
    protected Calendar dtIni;
    protected Calendar dtF;

    public Espaco getEsp() {
        return esp;
    }

    public void setEsp(Espaco esp) {
        this.esp = esp;
    }

    public Evento getEven() {
        return even;
    }

    public void setEven(Evento even) {
        this.even = even;
    }

    public Calendar getDtIni() {
        return dtIni;
    }

    public void setDtIni(Calendar dtIni) {
        this.dtIni = dtIni;
    }

    public Calendar getDtF() {
        return dtF;
    }

    public void setDtF(Calendar dtF) {
        this.dtF = dtF;
    }

}
