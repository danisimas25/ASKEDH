package model.dao;

import Connection.ConnectionFactory;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.bean.Espaco;

public class EspacoDAO {

    protected Connection c;

    public EspacoDAO() {
        this.c = new ConnectionFactory().getConnection();
    }

    public void inserirEspaco(Espaco e) {
        String sql = "call inserir_Esp(?,?,?,?,?,?)";
        try {
            CallableStatement stmt = c.prepareCall(sql);
            stmt.setString(1, e.getSigla());
            stmt.setString(2, e.getTipo());
            stmt.setInt(3, e.getQtdeCA());
            stmt.setInt(4, e.getCapacidade());
            stmt.setString(5, e.getDescricao());
            stmt.setInt(6, e.getDepto().getCodigo());
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void deletarEspaco(Espaco e) {
        
        String sql = "delete from Espaco where sigla = ?";
       
        try {
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setString(1, e.getSigla());
            ps.executeUpdate();
            ps.close();    
            JOptionPane.showMessageDialog(null, "Excluído com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: "+o);
        }
    }

    public List<Espaco> getLista() {
        List<Espaco> esp = new ArrayList<>();
        String sql = "call Lista_Esp()";
        PreparedStatement ps = null;
        ResultSet rs = null;
        DepartamentoDAO deptoDao = new DepartamentoDAO();
        try {
            ps = c.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Espaco e = new Espaco();
                e.setSigla(rs.getString("sigla"));
                e.setTipo(rs.getString("tipo"));
                e.setQtdeCA(rs.getInt("qtdeCA"));
                e.setCapacidade(rs.getInt("capacidade"));
                e.setDescricao(rs.getString("descricao"));
                e.setDepto(deptoDao.getDepartamento(rs.getInt("departamento")));
                esp.add(e);
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return esp;
    }

    public Espaco getEspaco(String sigla) {
        Espaco e = null;
        String sql = "pesquisa_Esp(?)";
        DepartamentoDAO dep = new DepartamentoDAO();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = c.prepareStatement(sql);
            ps.setString(1, "sigla");
            rs = ps.executeQuery();

            if (rs.next()) {
                e = new Espaco();
                e.setSigla(rs.getString("sigla"));
                e.setTipo(rs.getString("tipo"));
                e.setQtdeCA(rs.getInt("qtdeCA"));
                e.setCapacidade(rs.getInt("capacidade"));
                e.setDescricao(rs.getString("descricao"));
                e.setDepto(dep.getDepartamento(rs.getInt("departamento")));
            }
            rs.close();
            ps.close();

        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return e;
    }
}
