package model.dao;

import java.sql.Connection;
import Connection.ConnectionFactory;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.bean.Departamento;

public class DepartamentoDAO {

    protected Connection con;

    public DepartamentoDAO() {
        con = new ConnectionFactory().getConnection();
    }

    public void adicionarDepartamento(Departamento d) {
        String sql = "insert into Departamento values(?,?,?)";

        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, d.getCodigo());
            ps.setString(3, d.getSigla());
            ps.setString(2, d.getNome());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void atualizarDepartamento(Departamento d) {
        String sql = "update Departamento set nome = ? or  sigla = ? where codigo = ?";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, d.getNome());
            ps.setString(2, d.getSigla());
            ps.setInt(3, d.getCodigo());
            ps.executeUpdate();
            ps.close();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso !");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar:" + e);
        }
    }

    public void excluirDepartamento(Departamento d) {
        String sql = "delete from Departamento where codigo = ?";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, d.getCodigo());
            
            ps.executeUpdate();
            ps.close();
            
            JOptionPane.showMessageDialog(null, "Excluído com sucesso !");
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Erro ao excluir: "+e);
        }
    }

    public List<Departamento> getListaDepartamento() {
        List<Departamento> departamentos;
        departamentos = new ArrayList<>();
        String sql = "select * from departamento";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Departamento departamento = new Departamento();
                departamento.setCodigo(rs.getInt("codigo"));
                departamento.setNome(rs.getString("nome"));
                departamento.setSigla(rs.getString("sigla"));
                departamentos.add(departamento);
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return departamentos;
    }
 
     public List<Departamento> leituraPeloNome(String nome) {
        List<Departamento> departamentos;
        departamentos = new ArrayList<>();
        String sql = "select * from departamento where nome like ? ";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%"+nome+"%");
            rs = ps.executeQuery();

            while (rs.next()) {
                Departamento departamento = new Departamento();
                
                departamento.setCodigo(rs.getInt("codigo"));
                departamento.setNome(rs.getString("nome"));
                departamento.setSigla(rs.getString("sigla"));
                departamentos.add(departamento);
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return departamentos;
    }
    
    public Departamento getDepartamento(int dep) {
        Departamento departamento = null;
        String sql = "select * from departamento where codigo = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1,dep);
            rs = ps.executeQuery();

            if (rs.next()) {
                departamento = new Departamento();
                departamento.setCodigo(rs.getInt("codigo"));
                departamento.setNome(rs.getString("nome"));
                departamento.setSigla(rs.getString("sigla"));
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return departamento;
    }
}
