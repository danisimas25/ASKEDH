package model.dao;

import java.sql.Connection;
import java.sql.SQLException;
import Connection.ConnectionFactory;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.bean.Funcionario;
import model.dao.DepartamentoDAO;

public class FuncionarioDAO {

    protected Connection con;

    public FuncionarioDAO() {
        this.con = new ConnectionFactory().getConnection();
    }

    public void adicionarFuncionario(Funcionario f) {
        String sql = "insert into Funcionario values (?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getMatricula());
            ps.setString(2, f.getNome());
            ps.setString(3, f.getSenha());
            ps.setInt(4, f.getDepartamento().getCodigo());
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(null, "Cadastrado com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar: " + o);
        }
    }

    /*public void atulizarFuncionarioNome(Funcionario f) {
        String sql = "update Funcionario set nome = ? where matricula = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getNome());
            ps.setString(2, f.getMatricula());
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + o);
        }
    }
     public void atulizarFuncionarioSenha(Funcionario f) {
        String sql = "update Funcionario set senha = ? where matricula = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getSenha());
            ps.setString(2, f.getMatricula());
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + o);
        }
    }*/
     public void atulizarFuncionario(Funcionario f) {
        String sql = "update Funcionario set nome = ? , senha = ? where matricula = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getNome());
            ps.setString(2, f.getSenha());
            ps.setString(3, f.getMatricula());
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + o);
        }
    }

    public void deletarFuncionario(Funcionario f) {
        String sql = "delete from Funcionario where matricula = ?";
        try {
            con = new ConnectionFactory().getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getMatricula());
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(null, "Excluído com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + o);
        }
    }

    public List<Funcionario> getLista() {
        List<Funcionario> f = new ArrayList();
        String sql = "select * from funcionario";
        PreparedStatement ps = null;
        ResultSet rs = null;
        DepartamentoDAO ddao = new DepartamentoDAO();
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Funcionario func = new Funcionario();
                func.setMatricula(rs.getString("matricula"));
                func.setNome(rs.getString("nome"));
                func.setSenha(rs.getString("senha"));
                func.setDepartamento(ddao.getDepartamento(rs.getInt("departamento")));
                f.add(func);
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return f;
    }

    public List<Funcionario> leituraPelaMatricula(String matricula) {
        List<Funcionario> funcionarios;
        funcionarios = new ArrayList<>();
        String sql = "select * from funcionario where matricula = ? ";
        PreparedStatement ps = null;
        ResultSet rs = null;
        DepartamentoDAO departamentoDao = new DepartamentoDAO();

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "matricula");
            rs = ps.executeQuery();

            while (rs.next()) {
                Funcionario funcionario = new Funcionario();

                funcionario.setNome(rs.getString("nome"));
                funcionario.setMatricula(rs.getString("matricula"));
                funcionario.setSenha(rs.getString("senha"));
                funcionario.setDepartamento(departamentoDao.getDepartamento(rs.getInt("departamento")));
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return funcionarios;

    }

    public Funcionario getListaFuncionario(String matricula) {
        String sql = "select * from funcionario where matricula = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        Funcionario func = null;
        DepartamentoDAO departamentoDao = new DepartamentoDAO();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "matricula");
            rs = ps.executeQuery();

            while (rs.next()) {
                func = new Funcionario();
                func.setMatricula(rs.getString("matricula"));
                func.setNome(rs.getString("nome"));
                func.setSenha(rs.getString("senha"));
                func.setDepartamento(departamentoDao.getDepartamento(rs.getInt("departamento")));
            }

            rs.close();
            ps.close();
            JOptionPane.showMessageDialog(null, "Pesquisa realizada com sucesso !");
        } catch (SQLException o) {
            JOptionPane.showMessageDialog(null, "Erro ao realizar a pesquisa: " + o);
        }
        return func;
    }
}
