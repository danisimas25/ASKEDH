/*package model.dao;

import java.sql.Connection;
import Connection.ConnectionFactory;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import model.bean.EspEven;
import model.dao.EspacoDAO;
import model.dao.EspacoDAO;
import model.dao.EventoDAO;
import model.dao.EventoDAO;

public class EspEvenDAO {

    protected Connection con;

    public EspEvenDAO() {
        this.con = new ConnectionFactory().getConnection();
    }

    public void adicionarEspacoEvento(EspEven ve) {
        String sql = "insert into EspEven values(?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, ve.getEsp().getSigla());
            ps.setInt(2, ve.getEven().getCodigo());
            ps.setDate(3, (java.sql.Date) ve.getDtIni().getTime());
            ps.setDate(4, (java.sql.Date) ve.getDtF().getTime());
            ps.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<EspEven> listaEspEven() {
        List<EspEven> espEven;
        espEven = new ArrayList<>();
        String sql = "select * from espEven";
        PreparedStatement ps = null;
        ResultSet rs = null;
        EventoDAO even = null;
        EspacoDAO esp = null;
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                EspEven e = new EspEven();
                e.setEsp(esp.getEspaco(rs.getString("sigla")));
                e.setEven(even.getEvento(rs.getInt("codigo")));
                Calendar dI = Calendar.getInstance();
                dI.setTime(rs.getDate("dataInicio"));
                e.setDtIni(dI);
                Calendar dF = Calendar.getInstance();
                dF.setTime(rs.getDate("dataFinal"));
                e.setDtF(dF);
                espEven.add(e);
            }
            rs.close();
            ps.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return espEven;
    }

    public EspEven pesquisa(String siglaEs, int codEven) {
        String sql = "select * from espeven where siglaE = ? or evenCod = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        EspEven e = null;
        EventoDAO even = null;
        EspacoDAO esp = null;
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "siglaEs");
            ps.setInt(2, codEven);
            rs = ps.executeQuery();

            if (rs.next()) {
                e = new EspEven();
                e.setEsp(esp.getEspaco(rs.getString("sigla")));
                e.setEven(even.getEvento(rs.getInt("codigo")));
                Calendar dI = Calendar.getInstance();
                dI.setTime(rs.getDate("dataInicio"));
                e.setDtIni(dI);
                Calendar dF = Calendar.getInstance();
                dF.setTime(rs.getDate("dataFinal"));
                e.setDtF(dF);
            }
            rs.close();
            ps.close();
        } catch (SQLException p) {
            throw new RuntimeException(p);
        }
        return e;
    }

    public void atualizaEspEven(EspEven e) {
        String sql = "update espeven set dataFim = ? where siglaE = ?, evenCod = ? ";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDate(1, (java.sql.Date) e.getDtIni().getTime());
            ps.setString(2,e.getEsp().getSigla());
            ps.setInt(3,e.getEven().getCodigo());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException p) {
            throw new RuntimeException(p);
        }

    }
}
*/
