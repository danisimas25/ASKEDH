
package Tabelas;

import Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

public class InserirFunc {

    private Connection con;

    public InserirFunc() {
        con = new ConnectionFactory().getConnection();
    }

    public void inseriFunc(Funcionario f) throws SQLException {
        String sql = "insert into Funcionario" + "(nome,matricula,cargo,senha) "
                + "values(?,?,?,?)";
        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, f.getNome());
            ps.setString(2, f.getMatricula());
            ps.setString(3, f.getCargo());
//            Calendar d = f.getData();
//            Date da = new Date(d.getTimeInMillis());
//            ps.setDate(4, da);
            ps.setString(4,f.getSenha());
            ps.executeUpdate();
            ps.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
