package view;

import javax.swing.JOptionPane;
import model.bean.Departamento;
import model.bean.Espaco;
import model.dao.DepartamentoDAO;
import model.dao.EspacoDAO;

public class TelaCadEspaco extends javax.swing.JFrame {

    protected TelaInicio telaInicio;

    public TelaCadEspaco() {
        initComponents();
        setIconImage(new javax.swing.ImageIcon(getClass().getResource("/images/planeta.png")).getImage());
         DepartamentoDAO ddao = new DepartamentoDAO();
         EspacoDAO esp = new EspacoDAO();

        for (Departamento d : ddao.getListaDepartamento()) {
            cboBoxDeoCod.addItem(d);
        }
        for (Espaco e : esp.getLista()){
            cboBoxQtc.addItem(e);
        }
    }
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtSiglaEsp = new javax.swing.JTextField();
        labelSigla = new javax.swing.JLabel();
        labelTipo = new javax.swing.JLabel();
        labelQtdC = new javax.swing.JLabel();
        labelDesc = new javax.swing.JLabel();
        txtDescEsp = new javax.swing.JTextField();
        labelCap = new javax.swing.JLabel();
        cboBoxQtc = new javax.swing.JComboBox<>();
        btnMenuEsp = new javax.swing.JButton();
        btnCanEsp = new javax.swing.JButton();
        btnCadcEsp = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtQcEsp = new javax.swing.JTextField();
        txtCapEsp = new javax.swing.JTextField();
        cboBoxDeoCod = new javax.swing.JComboBox<>();
        labelTipo1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cadastro de espaços ");
        setSize(new java.awt.Dimension(1200, 710));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(1200, 678));

        txtSiglaEsp.setBackground(new java.awt.Color(0, 0, 0));
        txtSiglaEsp.setForeground(new java.awt.Color(255, 255, 255));
        txtSiglaEsp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        labelSigla.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelSigla.setForeground(new java.awt.Color(255, 255, 255));
        labelSigla.setText("Sigla");

        labelTipo.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelTipo.setForeground(new java.awt.Color(255, 255, 255));
        labelTipo.setText("Tipo");

        labelQtdC.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelQtdC.setForeground(new java.awt.Color(255, 255, 255));
        labelQtdC.setText("Quantidade de cadeiras");

        labelDesc.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelDesc.setForeground(new java.awt.Color(255, 255, 255));
        labelDesc.setText("Descrição");

        txtDescEsp.setBackground(new java.awt.Color(0, 0, 0));
        txtDescEsp.setForeground(new java.awt.Color(255, 255, 255));
        txtDescEsp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));
        txtDescEsp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescEspActionPerformed(evt);
            }
        });

        labelCap.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelCap.setForeground(new java.awt.Color(255, 255, 255));
        labelCap.setText("Capacidade");

        cboBoxQtc.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        cboBoxQtc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "S" }));
        cboBoxQtc.setBorder(null);
        cboBoxQtc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboBoxQtcActionPerformed(evt);
            }
        });

        btnMenuEsp.setBackground(new java.awt.Color(153, 153, 255));
        btnMenuEsp.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        btnMenuEsp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/voltar.png"))); // NOI18N
        btnMenuEsp.setText("Voltar");
        btnMenuEsp.setBorder(null);
        btnMenuEsp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMenuEspActionPerformed(evt);
            }
        });

        btnCanEsp.setBackground(new java.awt.Color(153, 153, 255));
        btnCanEsp.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        btnCanEsp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/limpar.png"))); // NOI18N
        btnCanEsp.setText("Limpar");
        btnCanEsp.setBorder(null);
        btnCanEsp.setFocusPainted(false);
        btnCanEsp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCanEspActionPerformed(evt);
            }
        });

        btnCadcEsp.setBackground(new java.awt.Color(153, 153, 255));
        btnCadcEsp.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        btnCadcEsp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cadastrar.png"))); // NOI18N
        btnCadcEsp.setText("Cadastrar");
        btnCadcEsp.setBorder(null);
        btnCadcEsp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadcEspActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/glxx.PNG"))); // NOI18N
        jLabel2.setText("jLabel2");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/glax1.PNG"))); // NOI18N
        jLabel3.setText("jLabel3");

        txtQcEsp.setBackground(new java.awt.Color(0, 0, 0));
        txtQcEsp.setForeground(new java.awt.Color(255, 255, 255));
        txtQcEsp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        txtCapEsp.setBackground(new java.awt.Color(0, 0, 0));
        txtCapEsp.setForeground(new java.awt.Color(255, 255, 255));
        txtCapEsp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        cboBoxDeoCod.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        cboBoxDeoCod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DQA", "DAIC", "DPI", "DAINFRA" }));
        cboBoxDeoCod.setBorder(null);
        cboBoxDeoCod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboBoxDeoCodActionPerformed(evt);
            }
        });

        labelTipo1.setFont(new java.awt.Font("Script MT Bold", 0, 24)); // NOI18N
        labelTipo1.setForeground(new java.awt.Color(255, 255, 255));
        labelTipo1.setText("Departamento");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(labelTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelSigla, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelQtdC, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelDesc)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(labelCap)
                                .addGap(113, 113, 113)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSiglaEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboBoxQtc, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtQcEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCapEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDescEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(labelTipo1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cboBoxDeoCod, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 130, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(56, 56, 56)
                        .addComponent(btnCanEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCadcEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(btnMenuEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 104, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cboBoxQtc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelTipo))
                                .addGap(16, 16, 16)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtSiglaEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelSigla))
                                .addGap(23, 23, 23)
                                .addComponent(txtQcEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(labelQtdC, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCapEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelCap, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDescEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboBoxDeoCod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelTipo1))
                        .addGap(96, 96, 96)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCanEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCadcEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnMenuEsp, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(51, 51, 51))
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)))
        );

        jMenu1.setBackground(new java.awt.Color(0, 0, 0));
        jMenu1.setBorder(null);
        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pasta.png"))); // NOI18N
        jMenu1.setText("Outras funções");
        jMenu1.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N

        jMenuItem1.setBackground(new java.awt.Color(0, 0, 0));
        jMenuItem1.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/editar.png"))); // NOI18N
        jMenuItem1.setText("Editar");
        jMenuItem1.setFocusPainted(true);
        jMenu1.add(jMenuItem1);

        jMenuItem2.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pesquisarr.png"))); // NOI18N
        jMenuItem2.setText("Pesquisar");
        jMenu1.add(jMenuItem2);

        jMenuItem3.setFont(new java.awt.Font("Script MT Bold", 0, 18)); // NOI18N
        jMenuItem3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/lista.png"))); // NOI18N
        jMenuItem3.setText("Listar");
        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1200, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 651, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 651, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cboBoxQtcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboBoxQtcActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboBoxQtcActionPerformed

    private void btnMenuEspActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMenuEspActionPerformed
        TelaInicio telaInicio = new TelaInicio();
        telaInicio.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnMenuEspActionPerformed

    private void btnCanEspActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCanEspActionPerformed
        limparTela();
    }//GEN-LAST:event_btnCanEspActionPerformed

    private void txtDescEspActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescEspActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescEspActionPerformed

    private void btnCadcEspActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadcEspActionPerformed

        Espaco e = new Espaco();
        EspacoDAO eDao = new EspacoDAO();
        e.setTipo((String) cboBoxQtc.getSelectedItem());
        e.setSigla(txtSiglaEsp.getText());
        e.setQtdeCA(Integer.parseInt(txtQcEsp.getText()));
        e.setCapacidade(Integer.parseInt(txtCapEsp.getText()));
        e.setDescricao(txtDescEsp.getText());
        e.setDepto((Departamento)cboBoxDeoCod.getSelectedItem());
        eDao.inserirEspaco(e);
        JOptionPane.showMessageDialog(this, "Cadastrado com sucesso!");

    }//GEN-LAST:event_btnCadcEspActionPerformed

    private void cboBoxDeoCodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboBoxDeoCodActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboBoxDeoCodActionPerformed

    private void limparTela() {
        txtCapEsp.setText("");
        txtDescEsp.setText("");
        txtQcEsp.setText("");
        txtSiglaEsp.setText("");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadEspaco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadEspaco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadEspaco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadEspaco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadEspaco().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadcEsp;
    private javax.swing.JButton btnCanEsp;
    private javax.swing.JButton btnMenuEsp;
    private javax.swing.JComboBox<Object> cboBoxDeoCod;
    private javax.swing.JComboBox<Object> cboBoxQtc;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel labelCap;
    private javax.swing.JLabel labelDesc;
    private javax.swing.JLabel labelQtdC;
    private javax.swing.JLabel labelSigla;
    private javax.swing.JLabel labelTipo;
    private javax.swing.JLabel labelTipo1;
    private javax.swing.JTextField txtCapEsp;
    private javax.swing.JTextField txtDescEsp;
    private javax.swing.JTextField txtQcEsp;
    private javax.swing.JTextField txtSiglaEsp;
    // End of variables declaration//GEN-END:variables
}
