package Tabelas;

import java.util.Calendar;

public class Funcionario {

    protected String nome;
    protected String matricula;
    protected String cargo;
//    protected Calendar dataDeNascimento;
    protected String senha;
    //protected Departamento dep;

    public void setNome(String n) {
        this.nome = n;
    }

    public void setMatricula(String m) {
        this.matricula = m;
    }

    public void setSenha(String s){
        this.senha=s;
    }

    public String getNome() {
        return this.nome;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public String getCargo() {
        return this.cargo;
    }
 
    public String getSenha(){
        return senha;
    }
    //public Departamento getDep(){ return this.dep;}

}
