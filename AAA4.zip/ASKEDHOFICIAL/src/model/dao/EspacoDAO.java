 package model.dao;

import Connection.ConnectionFactory;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.bean.Espaco;

public class EspacoDAO {

    protected Connection c;

    public EspacoDAO() {
        this.c = new ConnectionFactory().getConnection();
    }

    public void inserirEspaco(Espaco e) {
        String sql = "call inserir_Esp(?,?,?,?,?,?)";
        try {
            CallableStatement stmt = c.prepareCall(sql);
            stmt.setString(1, e.getSigla());
            stmt.setString(2, e.getTipo());
            stmt.setInt(3, e.getQtdeCA());
            stmt.setInt(4, e.getCapacidade());
            stmt.setString(5, e.getDescricao());
            stmt.setInt(6,e.getDepto().getCodigo());
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void atualizarEspaco(Espaco e) {
        String sql = "call atualiza_Esp(?,?,?,?,?,?)";
        try {
            CallableStatement stmt = c.prepareCall(sql);
            stmt.setInt(1, e.getQtdeCA());
            stmt.setInt(2, e.getCapacidade());
            stmt.setString(3, e.getDescricao());
            stmt.setInt(4,e.getDepto().getCodigo());
            stmt.setString(5, e.getSigla());
            stmt.setString(6,e.getTipo()+"");
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public void deletarEspaco(Espaco e) {
        String sql = "call deleta_Esp(?)";
        try {
            CallableStatement stmt = c.prepareCall(sql);
            stmt.setString(1, e.getSigla());
            stmt.execute();
            stmt.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
    }

    public List<Espaco> getLista() {
        List<Espaco> esp = new ArrayList<>();
        String sql = "call Lista_Esp()";
        PreparedStatement ps = null;
        ResultSet rs = null;
        DepartamentoDAO deptoDao=new DepartamentoDAO();
        try {
            ps = c.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Espaco e = new Espaco();
                e.setSigla(rs.getString("sigla"));
                e.setTipo(rs.getString("tipo").charAt(0));
                e.setQtdeCA(rs.getInt("qtdeCA"));
                e.setCapacidade(rs.getInt("capacidade"));
                e.setDescricao(rs.getString("descricao"));
                e.setDepto(deptoDao.getDepartamento(rs.getString("depCod")));
                esp.add(e);
            }
            rs.close();
            ps.close();
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return esp;
    }
    public Espaco getEspaco(String sigla) {
        Espaco e = null;
        String sql = "pesquisa_Esp(?)";
        DepartamentoDAO dep = new DepartamentoDAO();
        PreparedStatement ps=null;
        ResultSet rs=null;
        try {
            ps = c.prepareStatement(sql);
            ps.setString(1,"sigla");
            rs = ps.executeQuery();

            if (rs.next()) {
                e = new Espaco();
                e.setSigla(rs.getString("sigla"));
                e.setTipo(rs.getString("tipo").charAt(0));
                e.setQtdeCA(rs.getInt("qtdeCA"));
                e.setCapacidade(rs.getInt("capacidade"));
                e.setDescricao(rs.getString("descricao"));
                e.setDepto(dep.getDepartamento(rs.getString("depCod")));
            }
            rs.close();
            ps.close();
            
        } catch (SQLException o) {
            throw new RuntimeException(o);
        }
        return e;
    }
}
